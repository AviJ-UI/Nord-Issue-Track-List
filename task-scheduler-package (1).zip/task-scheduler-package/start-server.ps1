$ErrorActionPreference = "Stop"
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$port = 53214
$url = "http://localhost:$port/"

$mimeTypes = @{
    ".html" = "text/html"; ".htm" = "text/html"; ".js" = "application/javascript"
    ".css" = "text/css"; ".json" = "application/json"; ".png" = "image/png"
    ".jpg" = "image/jpeg"; ".jpeg" = "image/jpeg"; ".svg" = "image/svg+xml"
    ".ico" = "image/x-icon"
}

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add($url)

try {
    $listener.Start()
} catch {
    Write-Host ""
    Write-Host "Could not start the local server on port $port." -ForegroundColor Red
    Write-Host "Another program may already be using it. Close this window, edit start-server.ps1," -ForegroundColor Red
    Write-Host "change the `$port number near the top to something else (e.g. 53215), and try again." -ForegroundColor Red
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host ""
Write-Host "Task Scheduler is running at $url" -ForegroundColor Green
Write-Host "Keep this window open while you use the app." -ForegroundColor Yellow
Write-Host "Close this window (or press Ctrl+C) to stop the server." -ForegroundColor Yellow
Write-Host ""

Start-Process "$($url)task-scheduler.html"

try {
    while ($listener.IsListening) {
        $context = $listener.GetContext()
        $request = $context.Request
        $response = $context.Response

        $localPath = $request.Url.LocalPath.TrimStart("/")
        if ([string]::IsNullOrWhiteSpace($localPath)) { $localPath = "task-scheduler.html" }
        $filePath = Join-Path $scriptDir $localPath

        if (Test-Path $filePath -PathType Leaf) {
            $ext = [System.IO.Path]::GetExtension($filePath)
            $contentType = if ($mimeTypes.ContainsKey($ext)) { $mimeTypes[$ext] } else { "application/octet-stream" }
            $bytes = [System.IO.File]::ReadAllBytes($filePath)
            $response.ContentType = $contentType
            $response.ContentLength64 = $bytes.Length
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
        } else {
            $response.StatusCode = 404
            $notFound = [System.Text.Encoding]::UTF8.GetBytes("404 Not Found")
            $response.OutputStream.Write($notFound, 0, $notFound.Length)
        }
        $response.OutputStream.Close()
    }
} finally {
    $listener.Stop()
    $listener.Close()
}
