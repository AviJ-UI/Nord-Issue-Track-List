# Task Scheduler — local server launcher

This makes the Task Scheduler app run through `http://localhost` instead of
opening it directly as a file. That matters because Edge blocks browser
storage (which the app uses to auto-save your data) on files opened
directly — running it through localhost fixes that completely.

## Setup (one time)

1. Put these three files in the **same folder**:
   - `task-scheduler.html`
   - `start-server.ps1`
   - `Start Task Scheduler.bat`

## Every time you want to use the app

1. Double-click **`Start Task Scheduler.bat`**
2. A black window will open and your browser will open automatically to the app
3. Leave that black window open in the background while you work
4. When you're done, just close the black window (or press Ctrl+C in it)

## Notes

- No installation required — this uses tools already built into Windows.
- Your data now auto-saves with zero clicks needed, and the "Choose backup
  file" feature (if you use it) will also remember your file across reopens
  with just a single "Reconnect" click, instead of needing to reselect it
  from scratch.
- If Windows shows a firewall prompt the first time, click **Allow** —
  it's only for your own PC (localhost), nothing leaves your computer.
- If port 53214 is already used by something else on your PC, open
  `start-server.ps1` in Notepad, change the `$port = 53214` line to a
  different number (e.g. 53215), save, and try again.

## Share data between PC and phone

See **SETUP-GOOGLE-DRIVE.md** for the one-time setup. The `for-web-hosting` folder holds `index.html` (the same app) for putting on a web address so your phone can open it.
