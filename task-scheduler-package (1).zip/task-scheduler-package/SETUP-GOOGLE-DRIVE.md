# Share your tasks between PC and phone with Google Drive

The app saves your tasks to one small file (`task-scheduler-data.json`) in **your own Google Drive**.
Your PC and your phone both read and write that same file, so they always match.
Only you can open it: the app is only allowed to touch files it created itself.

You do the Google setup **once** (about 10 minutes). Google changes its console wording now and then,
so if a button is named slightly differently, look for the closest match.

---

## Part 1 — Create your Google sign-in key (once)

1. Go to **console.cloud.google.com** and sign in with the Google account you want to use.
2. Click the project picker at the top, then **New project**. Name it `Task Scheduler` and create it.
3. Open **APIs & Services > Library**, search for **Google Drive API**, and click **Enable**.
4. Open **APIs & Services > OAuth consent screen** (may be called *Google Auth Platform*):
   - User type: **External**. App name: `Task Scheduler`. Add your email as support and contact email.
   - Under **Data access / Scopes**, add this scope:
     `https://www.googleapis.com/auth/drive.file`
     (described as "See, edit, create and delete only the specific Google Drive files you use with this app").
   - Under **Audience / Test users**, add your own Google email address.
   - Optional but recommended: click **Publish app**. Because the app only asks for the `drive.file`
     permission, Google does not require a review. Publishing stops sign-in from expiring every 7 days.
5. Open **APIs & Services > Credentials > Create credentials > OAuth client ID**:
   - Application type: **Web application**.
   - Under **Authorized JavaScript origins**, add:
     - `http://localhost:53214`  (your PC launcher; use your own port if you changed it)
     - your phone web address from Part 2, for example `https://my-tasks.netlify.app`
   - Do **not** add any redirect URIs. No trailing slashes on the origins.
   - Click **Create** and copy the **Client ID** (it ends in `.apps.googleusercontent.com`).
   - New origins can take a few minutes to start working.

## Part 2 — Give your phone a web address (once)

A phone cannot reach `localhost` on your PC, so the app needs a normal `https` address.
The page contains no data, so hosting it is safe; your tasks live only in your Drive.

Easiest: **Netlify Drop**
1. Open the `for-web-hosting` folder from this package. It holds one file named `index.html` (the app).
2. Go to **app.netlify.com/drop** and drag that folder onto the page.
3. Netlify gives you an address like `https://something.netlify.app`. Create a free Netlify account
   when asked so the site is kept permanently.
4. Add that address to the **Authorized JavaScript origins** in Part 1, step 5.

(GitHub Pages or Cloudflare Pages also work if you already use them.)

When you update the app later, replace `index.html` on the host with the newest `task-scheduler.html`
(renamed to `index.html`).

## Part 3 — Connect each device (once per device)

1. Open the app. On your PC use `Start Task Scheduler.bat`. On your phone open your web address.
2. Tap the **cloud icon** in the top bar.
3. Paste your **Client ID** and tap **Connect Google Drive**. Sign in with the same Google account on both devices.
4. First device: the app creates the Drive file from your current data.
   Second device: the app asks whether to load what is in Drive. Choose **OK** to load it.
5. On your phone, use the browser menu **Add to Home screen** for an app-like icon.

The cloud icon shows a small dot: green = up to date, yellow = syncing or needs attention, red = problem.

## How it behaves

- Changes upload a few seconds after you make them. Each device checks Drive for changes every 30 seconds
  and whenever you come back to the app.
- If both devices were edited at the same moment, the app asks which version to keep (last choice wins).
- Roughly every hour Google may ask the app to sign in again. It usually does this silently. If the dot turns
  yellow and says **Sign-in needed**, open the cloud window and tap **Reconnect**.
- **Wallpaper is not synced** (each device keeps its own). Everything else is: tasks, updates, attachments, lists, title, logo, theme, Word template.
- Attachments and photos are stored inside the file, so many large attachments make syncing slower.
- The Drive file is named `task-scheduler-data.json`. Don't rename or delete it. If it is deleted, tap Reconnect to recreate it.
- Keep using **Save .json** now and then as a separate backup copy.

## Troubleshooting

- **"origin_mismatch" or a Google error page:** the address you opened is not in Authorized JavaScript origins,
  or it has a typo or trailing slash. Fix it in the console and wait a few minutes.
- **"Access blocked / not a test user":** add your email under Test users (or publish the app).
- **Nothing happens when you tap Connect:** your browser blocked the sign-in pop-up. Allow pop-ups for the page.
- **Message about opening the file directly:** use the launcher or the web address, not the raw HTML file.
